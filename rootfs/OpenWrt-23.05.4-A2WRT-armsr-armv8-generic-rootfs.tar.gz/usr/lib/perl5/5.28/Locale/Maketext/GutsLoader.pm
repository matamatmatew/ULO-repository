package Locale::Maketext::GutsLoader;

use Locale::Maketext;

our $VERSION = '1.20';

sub zorp { return scalar @_ }


1;
