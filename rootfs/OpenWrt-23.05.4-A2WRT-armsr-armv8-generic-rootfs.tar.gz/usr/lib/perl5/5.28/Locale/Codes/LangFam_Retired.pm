package #
Locale::Codes::LangFam_Retired;


use strict;
use warnings;
require 5.002;

our($VERSION);
$VERSION='3.56';

$Locale::Codes::Retired{'langfam'}{'alpha'}{'code'} = {
};

$Locale::Codes::Retired{'langfam'}{'alpha'}{'name'} = {
};


1;
